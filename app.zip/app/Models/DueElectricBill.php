<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DueElectricBill extends Model
{
    protected $table = 'customers';

   
}
