<?php

namespace App\Filament\Electricity\Resources\PreviousDues\Pages;

use App\Filament\Electricity\Resources\PreviousDues\PreviousDueResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePreviousDue extends CreateRecord
{
    protected static string $resource = PreviousDueResource::class;
}
