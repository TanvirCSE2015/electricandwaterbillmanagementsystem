<?php

namespace App\Filament\Electricity\Widgets;

use Filament\Widgets\Widget;

class CustomElectricInfo extends Widget
{
    protected string $view = 'filament.electricity.widgets.custom-electric-info';
    protected static bool $isLazy=false;
}
