

<?php
use Rakibhstu\Banglanumber\NumberToBangla;

$numto = new NumberToBangla();
function en2bn($number): string
{
    $en = ['0','1','2','3','4','5','6','7','8','9','January','February','March','April','May','June','July','August','September','October','November','December'];
    $bn = ['০','১','২','৩','৪','৫','৬','৭','৮','৯','জানুয়ারি','ফেব্রুয়ারি','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর'];
    return str_replace($en, $bn, $number);
}
?>

<?php $__env->startSection('main_content'); ?>
    <div class="text-center">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" srcset="">
        <h4>ঢাকা ক্যান্টনমেন্ট বোর্ড</h4>
        <h6>পূর্বের বকেয়া আদায়</h6>
        <?php if($type==='daily'): ?>
            <h6>দৈনিক রিপোর্ট</h6>
        <?php elseif($type === 'monthly'): ?>
            <h6>মাসিক রিপোর্ট</h6>
        <?php else: ?>
            <h6>বার্ষিক রিপোর্ট</h6>
        <?php endif; ?>

        <?php if($type==='daily'): ?>
            <h6><?php echo e($block_name ? $block_name : ''); ?></h6>
            <h6 class="text-decoration-underline" >তারিখঃ <?php echo e(en2bn($date)); ?> ইং</h6>
        <?php elseif($type === 'monthly'): ?>
            <h6><?php echo e($block_name ? $block_name : ''); ?></h6>
            <h6 class="text-decoration-underline" >মাসঃ <?php echo e($numto->bnMonth($month) .'-'. en2bn($year)); ?> ইং</h6>
         <?php else: ?>
            <h6><?php echo e($block_name ? $block_name : ''); ?></h6>
            <h6 class="text-decoration-underline" >বছরঃ <?php echo e(en2bn($year)); ?> ইং</h6>
        <?php endif; ?>


    </div>
    <div class="d-flex flex-row-reverse bd-highlight">
        <h6 class="p-2 bd-highlight">মোট আদায়: <?php echo e($numto->bnCommaLakh($total)); ?> /= </h6>
    </div>

    <table class="table table-bordered table-striped" id="sales-table">
    <thead>
        <tr class="text-center" style="font-size: 14px">
            <?php if($type==='daily'): ?>
                <th>রশিদ নং</th>
                <th>তারিখ</th>
                <th>গ্রাহকের নাম</th>
                <th>দোকান নং</th>
                <th>বিলের মাস</th>
                <th>মোট বিল</th>
            <?php elseif($type==='monthly'): ?>
                <th>তারিখ</th>
                <th>মাস</th>
                <th>বছর</th>
                <th>মোট বিল</th>
            <?php elseif($type==='yearly'): ?>
                <th>মাস</th>
                <th>বছর</th>
                <th>মোট বিল</th>
            <?php endif; ?>
            
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if($type==='daily'): ?>
                <tr class="text-center" style="font-size: 12px">
                    <td><?php echo e(en2bn($record->invoice_number)); ?></td>
                    <td><?php echo e(en2bn($record->invoice_date)); ?></td>
                    <td><?php echo e($record->customer->name); ?></td>
                    <td><?php echo e($record->customer->shop_no); ?></td>
                    <td><?php echo e(en2bn( $record->to_month ? $record->from_month . ' থেকে ' . $record->to_month : $record->from_month)); ?></td>
                    <td><?php echo e($numto->bnCommaLakh($record->total_amount)); ?></td>
                    
                </tr>
            <?php elseif($type==='monthly'): ?>
                <tr class="text-center" style="font-size: 14px">
                    <td><?php echo e(en2bn($record->invoice_date)); ?></td>
                    <td><?php echo e(en2bn($record->invoice_month_name)); ?></td>
                    <td><?php echo e(en2bn($record->invoice_year)); ?></td>
                    <td><?php echo e($numto->bnCommaLakh($record->total_amount)); ?></td>
                </tr>
            <?php elseif($type==='yearly'): ?>
                <tr class="text-center" style="font-size: 14px">
                    <td><?php echo e(en2bn($record->invoice_month_name)); ?></td>
                    <td><?php echo e(en2bn($record->invoice_year)); ?></td>
                    <td><?php echo e($numto->bnCommaLakh($record->total_amount)); ?></td>
                </tr>
            <?php endif; ?>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="7">No records found.</td>
            </tr>
        <?php endif; ?>
        <?php if($type==='daily'): ?>
            <tr>
                <td colspan="5" class="text-end">মোট আদায়</td>
                <td><?php echo e($numto->bnCommaLakh($total)); ?></td>
            </tr>
             <tr>
                <td colspan="2" class="text-end">মোট আদায় কথায়</td> 
                <td colspan="4" class="text-end"><?php echo e($numto->bnMoney($total) . ' মাত্র'); ?></td>
            </tr>
         <?php elseif($type==='monthly'): ?>
            <tr class="text-center">
                <td colspan="3" class="text-end">মোট আদায়</td>
                <td class="text-center"><?php echo e($numto->bnCommaLakh($total)); ?></td>
            </tr>
             <tr>
                <td colspan="1" class="text-end">মোট আদায় কথায়</td> 
                <td colspan="3" class="text-end"><?php echo e($numto->bnMoney($total) . ' মাত্র'); ?></td>
            </tr>
        <?php elseif($type==='yearly'): ?>
            <tr>
                <td colspan="2" class="text-end">মোট আদায়</td>
                <td class="text-center"><?php echo e($numto->bnCommaLakh($total)); ?></td>
            </tr>
             <tr>
                <td colspan="1" class="text-end">মোট আদায় কথায়</td> 
                <td colspan="2" class="text-end"><?php echo e($numto->bnMoney($total) . ' মাত্র'); ?></td>
            </tr>
        <?php endif; ?>
         
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('reports.layouts.report_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\electricandwaterbillmanagementsystem\resources\views/reports/electric_pre_due_invoice.blade.php ENDPATH**/ ?>