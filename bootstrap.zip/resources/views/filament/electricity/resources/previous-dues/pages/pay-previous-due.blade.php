<x-filament-panels::page>
    {{-- Page content --}}
    {{ $this->form }}
</x-filament-panels::page>
