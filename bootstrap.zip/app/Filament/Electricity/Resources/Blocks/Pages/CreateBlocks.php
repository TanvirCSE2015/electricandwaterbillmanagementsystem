<?php

namespace App\Filament\Electricity\Resources\Blocks\Pages;

use App\Filament\Electricity\Resources\Blocks\BlocksResource;
use Filament\Resources\Pages\CreateRecord;

class CreateBlocks extends CreateRecord
{
    protected static string $resource = BlocksResource::class;
}
