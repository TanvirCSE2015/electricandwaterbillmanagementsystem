<?php
use App\Helpers\ElectricBillHelper;
use Rakibhstu\Banglanumber\NumberToBangla;

$numto = new NumberToBangla();
?>
<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <?php echo e($this->form); ?>

    <?php
        $data=DB::table('electric_bills')->where('customer_id', $this->record->id)->where('is_paid', false)
        ->orderBy('id', 'asc')->limit($this->count)->get();
        $dueTotal=0;
        foreach ($data as $bill) {
            if ($bill->surcharge > 0) {
                    $dueTotal += $bill->total_amount;
                    continue;
            }else{
                $surcharge= ElectricBillHelper::calculateSurcharge($bill);
                    $dueTotal += $bill->total_amount + $surcharge;
            }
        }
    $previousDue = DB::table('previous_dues')->where(['customer_id' => $this->record->id,'is_paid' =>false])->first();
    ?>
    
    <?php echo e($this->table); ?>

    <div style="width:100%;display:flex;justify-content:flex-end;margin-top: -25px;padding-right: 3.5rem; color: red;">
        <span style="font-weight:bold;">
            পূর্বের বকেয়া: <?php echo e($numto->bnCommaLakh(round($previousDue->amount ?? 0))); ?> /= 
        </span>
    </div>
    <div style="width:100%;display:flex;justify-content:flex-end;margin-top: -25px;padding-right: 3.5rem;">
        <span style="font-weight:bold;">
            মোট বকেয়া: <?php echo e($numto->bnCommaLakh(round($dueTotal + $previousDue?->amount ?? 0))); ?> /= 
        </span>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel\electricandwaterbillmanagementsystem\resources\views/filament/electricity/resources/due-electric-bills/pages/due-electric-bill-details.blade.php ENDPATH**/ ?>